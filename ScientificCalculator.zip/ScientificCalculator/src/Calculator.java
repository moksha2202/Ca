import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.SystemColor;
import javax.swing.JLabel;
import java.awt.BorderLayout;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Color;
import javax.swing.UIManager;
import javax.swing.JRadioButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.ButtonGroup;

public class Calculator {

	private JFrame frmCalculator;
	private JTextField textField;
	
	double first;
	double second;
	double operation;
	String operations;
	double result;
	String answer;
	private final ButtonGroup buttonGroup = new ButtonGroup();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Calculator window = new Calculator();
					window.frmCalculator.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Calculator() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmCalculator = new JFrame();
		frmCalculator.setFont(new Font("Dialog", Font.BOLD, 16));
		frmCalculator.getContentPane().setBackground(UIManager.getColor("CheckBox.darkShadow"));
		frmCalculator.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel(" Scientific Calculator");
		lblNewLabel.setBounds(81, 0, 273, 53);
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 26));
		lblNewLabel.setBackground(UIManager.getColor("Button.light"));
		frmCalculator.getContentPane().add(lblNewLabel);
		
		textField = new JTextField();
		textField.setFont(new Font("Arial", Font.PLAIN, 16));
		textField.setBounds(24, 46, 375, 73);
		frmCalculator.getContentPane().add(textField);
		textField.setColumns(10);
		
		JButton btnRoot = new JButton("\u221A");
		btnRoot.setEnabled(false);
		btnRoot.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				double a=Math.sqrt(Double.parseDouble(textField.getText()));
				textField.setText("");
				textField.setText(textField.getText()+a);
			}
		});
		btnRoot.setBackground(SystemColor.controlShadow);
		btnRoot.setFont(new Font("Arial", Font.PLAIN, 24));
		btnRoot.setBounds(26, 166, 67, 53);
		frmCalculator.getContentPane().add(btnRoot);
		
		JButton btnNewButton_1 = new JButton("1/x");
		btnNewButton_1.setEnabled(false);
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				double a=1/(Double.parseDouble(textField.getText()));
				textField.setText("");
				textField.setText(textField.getText()+a);
			}
		});
		btnNewButton_1.setFont(new Font("Arial", Font.PLAIN, 24));
		btnNewButton_1.setBackground(SystemColor.controlShadow);
		btnNewButton_1.setBounds(26, 221, 67, 53);
		frmCalculator.getContentPane().add(btnNewButton_1);
		
		JButton btnXSqr3 = new JButton("X^3");
		btnXSqr3.setEnabled(false);
		btnXSqr3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				double a=(Double.parseDouble(textField.getText()));
				a=a*a*a;
				textField.setText("");
				textField.setText(textField.getText()+a);
			}
		});
		btnXSqr3.setFont(new Font("Arial", Font.PLAIN, 18));
		btnXSqr3.setBackground(SystemColor.controlShadow);
		btnXSqr3.setBounds(26, 331, 67, 53);
		frmCalculator.getContentPane().add(btnXSqr3);
		
		JButton btnSqr2 = new JButton("X^2");
		btnSqr2.setEnabled(false);
		btnSqr2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				double a=(Double.parseDouble(textField.getText()));
				a=a*a;
				textField.setText("");
				textField.setText(textField.getText()+a);
			}
		});
		btnSqr2.setFont(new Font("Arial", Font.PLAIN, 18));
		btnSqr2.setBackground(SystemColor.controlShadow);
		btnSqr2.setBounds(26, 387, 67, 53);
		frmCalculator.getContentPane().add(btnSqr2);
		
		JButton btnFactorial = new JButton("n!");
		btnFactorial.setEnabled(false);
		btnFactorial.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Double a =Double.parseDouble(textField.getText());
				double fact=1;
				while (a!=0)
				{
					fact=fact*a;
					a--;
				}
				textField.setText("");
				textField.setText(textField.getText()+fact);
			}
		});
		btnFactorial.setFont(new Font("Arial", Font.PLAIN, 22));
		btnFactorial.setBackground(SystemColor.controlShadow);
		btnFactorial.setBounds(26, 444, 67, 53);
		frmCalculator.getContentPane().add(btnFactorial);
		
		JButton btnPlusMinus = new JButton("+/-");
		btnPlusMinus.setEnabled(false);
		btnPlusMinus.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				double a=Double.parseDouble(String.valueOf(textField.getText()));
				a=a*(-1);
				textField.setText(String.valueOf(a));
						
			}
		});
		btnPlusMinus.setFont(new Font("Arial", Font.PLAIN, 24));
		btnPlusMinus.setBackground(SystemColor.controlShadow);
		btnPlusMinus.setBounds(26, 501, 67, 53);
		frmCalculator.getContentPane().add(btnPlusMinus);
		
		JButton btnExp = new JButton("e^x");
		btnExp.setEnabled(false);
		btnExp.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				double a=Math.exp(Double.parseDouble(textField.getText()));
				textField.setText("");
				textField.setText(textField.getText()+a);
			}
		});
		btnExp.setFont(new Font("Arial", Font.PLAIN, 20));
		btnExp.setBackground(SystemColor.controlShadow);
		btnExp.setBounds(103, 166, 67, 53);
		frmCalculator.getContentPane().add(btnExp);
		
		JButton btn7 = new JButton("7");
		btn7.setEnabled(false);
		btn7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String number=textField.getText()+btn7.getText();
				textField.setText(number);
			}
		});
		btn7.setFont(new Font("Arial Rounded MT Bold", Font.BOLD, 24));
		btn7.setBackground(SystemColor.controlShadow);
		btn7.setBounds(103, 331, 67, 53);
		frmCalculator.getContentPane().add(btn7);
		
		JButton btn4 = new JButton("4");
		btn4.setEnabled(false);
		btn4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String number=textField.getText()+btn4.getText();
				textField.setText(number);
			}
		});
		btn4.setFont(new Font("Arial Rounded MT Bold", Font.BOLD, 24));
		btn4.setBackground(SystemColor.controlShadow);
		btn4.setBounds(103, 387, 67, 53);
		frmCalculator.getContentPane().add(btn4);
		
		JButton btn1 = new JButton("1");
		btn1.setEnabled(false);
		btn1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			    String number=textField.getText()+btn1.getText();
				textField.setText(number);
			}
		});
		btn1.setFont(new Font("Arial Rounded MT Bold", Font.BOLD, 24));
		btn1.setBackground(SystemColor.controlShadow);
		btn1.setBounds(103, 444, 67, 53);
		frmCalculator.getContentPane().add(btn1);
		
		JButton btn0 = new JButton("0");
		btn0.setEnabled(false);
		btn0.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String number=textField.getText()+btn0.getText();
				textField.setText(number);
			}
		});
		btn0.setFont(new Font("Arial Rounded MT Bold", Font.BOLD, 24));
		btn0.setBackground(SystemColor.controlShadow);
		btn0.setBounds(103, 501, 144, 53);
		frmCalculator.getContentPane().add(btn0);
		
		JButton btnSin = new JButton("Sin");
		btnSin.setEnabled(false);
		btnSin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				double a=Math.sin(Double.parseDouble(textField.getText()));
				textField.setText("");
				textField.setText(textField.getText()+a);
				
			}
		});
		btnSin.setFont(new Font("Arial", Font.PLAIN, 20));
		btnSin.setBackground(SystemColor.controlShadow);
		btnSin.setBounds(180, 166, 67, 53);
		frmCalculator.getContentPane().add(btnSin);
		
		JButton btn8 = new JButton("8");
		btn8.setEnabled(false);
		btn8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String number=textField.getText()+btn8.getText();
				textField.setText(number);
			}
		});
		btn8.setFont(new Font("Arial Rounded MT Bold", Font.BOLD, 24));
		btn8.setBackground(SystemColor.controlShadow);
		btn8.setBounds(180, 331, 67, 53);
		frmCalculator.getContentPane().add(btn8);
		
		JButton btn5 = new JButton("5");
		btn5.setEnabled(false);
		btn5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String number=textField.getText()+btn5.getText();
				textField.setText(number);
			}
		});
		btn5.setFont(new Font("Arial Rounded MT Bold", Font.BOLD, 24));
		btn5.setBackground(SystemColor.controlShadow);
		btn5.setBounds(180, 387, 67, 53);
		frmCalculator.getContentPane().add(btn5);
		
		JButton btn2 = new JButton("2");
		btn2.setEnabled(false);
		btn2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String number=textField.getText()+btn2.getText();
				textField.setText(number);
			}
		});
		btn2.setFont(new Font("Arial Rounded MT Bold", Font.BOLD, 24));
		btn2.setBackground(SystemColor.controlShadow);
		btn2.setBounds(180, 444, 67, 53);
		frmCalculator.getContentPane().add(btn2);
		
		JButton btnBackSpace = new JButton("\uF0E7");
		btnBackSpace.setEnabled(false);
		btnBackSpace.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String backSpace=null;
				if (textField.getText().length()>0 )
				{
					StringBuilder str=new StringBuilder(textField.getText());
					str.deleteCharAt(textField.getText().length()-1);
					backSpace=str.toString();
					textField.setText(backSpace);
				}
				
			}
		});
		btnBackSpace.setFont(new Font("Arial", Font.BOLD, 16));
		btnBackSpace.setBackground(SystemColor.controlShadow);
		btnBackSpace.setBounds(257, 276, 67, 53);
		frmCalculator.getContentPane().add(btnBackSpace);
		
		JButton btn9 = new JButton("9");
		btn9.setEnabled(false);
		btn9.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String number=textField.getText()+btn9.getText();
				textField.setText(number);
			}
		});
		btn9.setFont(new Font("Arial Rounded MT Bold", Font.BOLD, 24));
		btn9.setBackground(SystemColor.controlShadow);
		btn9.setBounds(257, 331, 67, 53);
		frmCalculator.getContentPane().add(btn9);
		
		JButton btn6 = new JButton("6");
		btn6.setEnabled(false);
		btn6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String number=textField.getText()+btn6.getText();
				textField.setText(number);
			}
		});
		btn6.setFont(new Font("Arial Rounded MT Bold", Font.BOLD, 24));
		btn6.setBackground(SystemColor.controlShadow);
		btn6.setBounds(257, 387, 67, 53);
		frmCalculator.getContentPane().add(btn6);
		
		JButton btn3 = new JButton("3");
		btn3.setEnabled(false);
		btn3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String number=textField.getText()+btn3.getText();
				textField.setText(number);
			}
		});
		btn3.setFont(new Font("Arial Rounded MT Bold", Font.BOLD, 24));
		btn3.setBackground(SystemColor.controlShadow);
		btn3.setBounds(257, 444, 67, 53);
		frmCalculator.getContentPane().add(btn3);
		
		JButton btnDot = new JButton(".");
		btnDot.setEnabled(false);
		btnDot.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String number=textField.getText()+btnDot.getText();
				textField.setText(number);
			}
		});
		btnDot.setFont(new Font("Arial Rounded MT Bold", Font.BOLD, 24));
		btnDot.setBackground(SystemColor.controlShadow);
		btnDot.setBounds(257, 501, 67, 53);
		frmCalculator.getContentPane().add(btnDot);
		
		JButton btnEqual = new JButton("=");
		btnEqual.setEnabled(false);
		btnEqual.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				second=Double.parseDouble(textField.getText());
				if (operation =='+')
				{
					result=first+second;
					answer=String.format("%.2f", result);
					textField.setText(answer);
					
				}
				else if (operation =='-')
				{
					result=first-second;
					answer=String.format("%.2f", result);
					textField.setText(answer);
					
				}
				else if (operation =='*')
				{
					result=first*second;
					answer=String.format("%.2f", result);
					textField.setText(answer);
					
				}
				else if (operation =='/')
				{
					result=first/second;
					answer=String.format("%.2f", result);
					textField.setText(answer);
					
				}
				else if (operation =='%')
				{
					result=first%second;
					answer=String.format("%.2f", result);
					textField.setText(answer);
					
				}
				else if (operations== "X^Y")
	             {
				double resultt=1;
				for (int i=0;i<second;i++)
				{
					resultt=first*resultt;
				}
				answer=String.format("%.2f", resultt);
				textField.setText(answer);
			}
				

			}
		});
		btnEqual.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 24));
		btnEqual.setBackground(SystemColor.controlShadow);
		btnEqual.setBounds(332, 501, 67, 53);
		frmCalculator.getContentPane().add(btnEqual);
		
		JButton btnDivide = new JButton("/");
		btnDivide.setEnabled(false);
		btnDivide.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				first=Double.parseDouble(textField.getText());
				textField.setText("");
				operation='/';
			}
		});
		btnDivide.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 24));
		btnDivide.setBackground(SystemColor.controlShadow);
		btnDivide.setBounds(332, 444, 67, 53);
		frmCalculator.getContentPane().add(btnDivide);
		
		JButton btnMultiply = new JButton("*");
		btnMultiply.setEnabled(false);
		btnMultiply.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				first=Double.parseDouble(textField.getText());
				textField.setText("");
				operation='*';
			}
		});
		btnMultiply.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 24));
		btnMultiply.setBackground(SystemColor.controlShadow);
		btnMultiply.setBounds(332, 387, 67, 53);
		frmCalculator.getContentPane().add(btnMultiply);
		
		JButton btnSub = new JButton("-");
		btnSub.setEnabled(false);
		btnSub.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				first=Double.parseDouble(textField.getText());
				textField.setText("");
				operation='-';
			}
		});
		btnSub.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 24));
		btnSub.setBackground(SystemColor.controlShadow);
		btnSub.setBounds(332, 331, 67, 53);
		frmCalculator.getContentPane().add(btnSub);
		
		JButton btnAdd = new JButton("+");
		btnAdd.setEnabled(false);
		btnAdd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				first=Double.parseDouble(textField.getText());
				textField.setText("");
				operation='+';
				
			}
		});
		btnAdd.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 24));
		btnAdd.setBackground(SystemColor.controlShadow);
		btnAdd.setBounds(332, 276, 67, 53);
		frmCalculator.getContentPane().add(btnAdd);
		
		JButton btnClear = new JButton("C");
		btnClear.setEnabled(false);
		btnClear.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			   textField.setText(null);
			}
		});
		btnClear.setFont(new Font("Arial", Font.BOLD, 24));
		btnClear.setBackground(SystemColor.controlShadow);
		btnClear.setBounds(180, 276, 67, 53);
		frmCalculator.getContentPane().add(btnClear);
		
		JButton btnPercent = new JButton("%");
		btnPercent.setEnabled(false);
		btnPercent.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				first=Double.parseDouble(textField.getText());
				textField.setText("");
				operation='%';
			}
		});
		btnPercent.setFont(new Font("Arial", Font.BOLD, 24));
		btnPercent.setBackground(SystemColor.controlShadow);
		btnPercent.setBounds(103, 276, 67, 53);
		frmCalculator.getContentPane().add(btnPercent);
		
		JButton btnXy = new JButton("X^Y");
		btnXy.setEnabled(false);
		btnXy.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				first=Double.parseDouble(textField.getText());
	            textField.setText("");
	            operations="X^Y";
	            
			}
		});
		btnXy.setFont(new Font("Arial", Font.PLAIN, 17));
		btnXy.setBackground(SystemColor.controlShadow);
		btnXy.setBounds(26, 276, 67, 53);
		frmCalculator.getContentPane().add(btnXy);
		
		JButton btnCos = new JButton("Cos");
		btnCos.setEnabled(false);
		btnCos.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				double a=Math.cos(Double.parseDouble(textField.getText()));
				textField.setText("");
				textField.setText(textField.getText()+a);
			}
		});
		btnCos.setFont(new Font("Arial", Font.PLAIN, 17));
		btnCos.setBackground(SystemColor.controlShadow);
		btnCos.setBounds(257, 166, 67, 53);
		frmCalculator.getContentPane().add(btnCos);
		
		JButton btnTan = new JButton("Tan");
		btnTan.setEnabled(false);
		btnTan.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				double a=Math.tan(Double.parseDouble(textField.getText()));
				textField.setText("");
				textField.setText(textField.getText()+a);
			}
		});
		btnTan.setFont(new Font("Arial", Font.PLAIN, 17));
		btnTan.setBackground(SystemColor.controlShadow);
		btnTan.setBounds(332, 166, 67, 53);
		frmCalculator.getContentPane().add(btnTan);
		
		JButton btnSinh = new JButton("Sinh");
		btnSinh.setEnabled(false);
		btnSinh.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				double a=Math.sinh(Double.parseDouble(textField.getText()));
				textField.setText("");
				textField.setText(textField.getText()+a);
			}
		});
		btnSinh.setFont(new Font("Arial", Font.PLAIN, 16));
		btnSinh.setBackground(SystemColor.controlShadow);
		btnSinh.setBounds(180, 221, 67, 53);
		frmCalculator.getContentPane().add(btnSinh);
		
		JButton btnCosh = new JButton("Cosh");
		btnCosh.setEnabled(false);
		btnCosh.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				double a=Math.cosh(Double.parseDouble(textField.getText()));
				textField.setText("");
				textField.setText(textField.getText()+a);
			}
		});
		btnCosh.setFont(new Font("Arial", Font.PLAIN, 13));
		btnCosh.setBackground(SystemColor.controlShadow);
		btnCosh.setBounds(257, 221, 67, 53);
		frmCalculator.getContentPane().add(btnCosh);
		
		JButton btnTanh = new JButton("Tanh");
		btnTanh.setEnabled(false);
		btnTanh.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				double a=Math.tanh(Double.parseDouble(textField.getText()));
				textField.setText("");
				textField.setText(textField.getText()+a);
			}
		});
		btnTanh.setFont(new Font("Arial", Font.PLAIN, 13));
		btnTanh.setBackground(SystemColor.controlShadow);
		btnTanh.setBounds(332, 221, 67, 53);
		frmCalculator.getContentPane().add(btnTanh);
		
		JButton btnLog = new JButton("Log");
		btnLog.setEnabled(false);
		btnLog.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				double a=Math.log(Double.parseDouble(textField.getText()));
				textField.setText("");
				textField.setText(textField.getText()+a);
			}
		});
		btnLog.setFont(new Font("Arial", Font.PLAIN, 18));
		btnLog.setBackground(SystemColor.controlShadow);
		btnLog.setBounds(103, 221, 67, 53);
		frmCalculator.getContentPane().add(btnLog);
		
		JRadioButton rdbtnNewRadioButton = new JRadioButton("ON");
		rdbtnNewRadioButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btn0.setEnabled(true);
				btn1.setEnabled(true);
				btn2.setEnabled(true);
				btn3.setEnabled(true);
				btn4.setEnabled(true);
				btn5.setEnabled(true);
				btn6.setEnabled(true);
				btn7.setEnabled(true);
				btn8.setEnabled(true);
				btn9.setEnabled(true);

				btnDot.setEnabled(true);
				btnAdd.setEnabled(true);
				btnSub.setEnabled(true);
				btnMultiply.setEnabled(true);
				btnDivide.setEnabled(true);
				btnPercent.setEnabled(true);
				
				btnEqual.setEnabled(true);
				btnBackSpace.setEnabled(true);
				btnClear.setEnabled(true);
				btnRoot.setEnabled(true);
				btnPlusMinus.setEnabled(true);
				btnXy.setEnabled(true);
				
				btnTanh.setEnabled(true);
				btnTan.setEnabled(true);
				btnCosh.setEnabled(true);
				btnCos.setEnabled(true);
				btnSin.setEnabled(true);
				btnSinh.setEnabled(true);
				btnLog.setEnabled(true);
				btnExp.setEnabled(true);
				
				btnNewButton_1.setEnabled(true);
				btnXSqr3.setEnabled(true);
				btnSqr2.setEnabled(true);
				btnFactorial.setEnabled(true);
				textField.setEnabled(true);

			}
		});
		buttonGroup.add(rdbtnNewRadioButton);
		rdbtnNewRadioButton.setBackground(UIManager.getColor("CheckBox.shadow"));
		rdbtnNewRadioButton.setFont(new Font("Arial Rounded MT Bold", Font.BOLD, 16));
		rdbtnNewRadioButton.setBounds(24, 135, 69, 25);
		frmCalculator.getContentPane().add(rdbtnNewRadioButton);
		
		JRadioButton rdbtnOff = new JRadioButton("OFF");
		rdbtnOff.setSelected(true);
		rdbtnOff.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textField.setText(null);
				btn0.setEnabled(false);
				btn1.setEnabled(false);
				btn2.setEnabled(false);
				btn3.setEnabled(false);
				btn4.setEnabled(false);
				btn5.setEnabled(false);
				btn6.setEnabled(false);
				btn7.setEnabled(false);
				btn8.setEnabled(false);
				btn9.setEnabled(false);

				btnDot.setEnabled(false);
				btnAdd.setEnabled(false);
				btnSub.setEnabled(false);
				btnMultiply.setEnabled(false);
				btnDivide.setEnabled(false);
				btnPercent.setEnabled(false);
				
				btnEqual.setEnabled(false);
				btnBackSpace.setEnabled(false);
				btnClear.setEnabled(false);
				btnRoot.setEnabled(false);
				btnPlusMinus.setEnabled(false);
				btnXy.setEnabled(false);
				
				btnTanh.setEnabled(false);
				btnTan.setEnabled(false);
				btnCosh.setEnabled(false);
				btnCos.setEnabled(false);
				btnSin.setEnabled(false);
				btnSinh.setEnabled(false);
				btnLog.setEnabled(false);
				btnExp.setEnabled(false);
				
				btnNewButton_1.setEnabled(false);
				btnXSqr3.setEnabled(false);
				btnSqr2.setEnabled(false);
				btnFactorial.setEnabled(false);
				textField.setEnabled(false);

			}
		});
		buttonGroup.add(rdbtnOff);
		rdbtnOff.setFont(new Font("Arial Rounded MT Bold", Font.BOLD, 16));
		rdbtnOff.setBackground(UIManager.getColor("CheckBox.shadow"));
		rdbtnOff.setBounds(101, 135, 69, 25);
		frmCalculator.getContentPane().add(rdbtnOff);
		frmCalculator.setBounds(100, 100, 436, 603);
		frmCalculator.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}
